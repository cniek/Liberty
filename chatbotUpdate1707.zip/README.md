# Liberty
Liberty Chatbot UI


npm init <br>
npm install dialogflow <br>
npm install uuid express body-parser <br>
npm install --save dialogflow <br>


to run app: <br>
node app <br>
